OpenProdoc Portable (EN)
**************************************************************************

Installation
-----------
- This portable version can run on any operating system that has Java 1.6 or higher.
- This version uses the embedded DDBB HSQLDB and a Jetty J2EE server and stores the metadata in the DB folder.
- Documents are stored in the folder Rep and Fulltext index in RepFT.
- To install just unzip the Zip file to a folder on your computer (or a USB device)
- To start just run the script for your operating system (.Sh, .Command or .Bat).
- In some cases, it may be necessary to assign execute permissions in Linux to the script (rwx-rwx-rwx).
- If the program can't start, can be due the lack of Java installed or because the java.exe command is not included in the system path.
  Verify that Java is installed and if needed, change the path to the java bin folder or change the script from "java" 
  to a complete path (i.e. c:\Program Files\Java\jre1.8.0_25\bin\java.exe)
- The default configuration of OpenProdoc starts the server using port 8080 (to avoid security restriction in Linux )
  and can be accesed from any browser using the url ( http://localhost:8080/ProdocWeb2 ) from the server computer itelf or 
  from other computers replacing "localhost" with the name of the server computer (Ej. http://PCServer:8080/ProdocWeb2 )
- The server stops in a controlled way pressing control-C (in any operative system) in the server window

Documentation
-------------
All documentation is available in the folder 'doc', grouped by language: English (EN) and Spanish (ES).

Security
----------
By default is active the administrator user 'root' with password 'root'.
        - 'Usuario' with password 'Usuario', Spanish User Interfaz and 'Administrator' role
        - 'User' with password  'User', English User Interfaz and 'Administrator' role
        - 'Utilizador' with password  'Utilizador' Portuguese User Interfaz and 'Administrator' role
        - 'Usuari' with password  'Usuari', Català User Interfaz and 'Administrator' role

IT IS RECOMMENDED TO CHANGE THE DEFAULT PASSWORDS, especially if it is stored on a USB.

You can create an encrypted storage if you store the documents in USB.
You need to:
        - create a PC folder on a par with 'Rep' (ie RepEncrip).
        - copy the default repository definition in OpenProdoc.
        - introduce the new folder and activate encryption.
You can then define document types that are stored in the new repository (or change the definition of existing ones).
ATTENTION, the encryption system is simple and only protects a casual observer.
For highly confidential documentation is recommended to use another system-level Advanced Encryption File System.

Compatibility
--------------
This version is fully compatible with other versions of OpenProdoc (of the same versión number).
Itsn't limited in any way in functionality, being able to define multiple users with different access levels (though not simultaneously).
The documents and definitions can be imported and exported between versions.
Even if the BB.DD. is "published" with a full version of HSQLDB (not embedded) could be used
for multiple users with version ProdocSwing or J2EE-Web.


