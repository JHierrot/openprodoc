export OPDL=./webapps/ProdocWeb2/WEB-INF/lib
java -Dfile.encoding=UTF-8 -classpath .:$OPDL/commons-io-2.5.jar:$OPDL/commons-codec-1.10.jar:$OPDL/Prodoc.jar:ProdocSwing.jar:$OPDL/log4j-1.2.16.jar:$OPDL/hsqldb.jar:$OPDL/commons-net-3.6.jar:$OPDL/tika-app-1.10.jar:$OPDL/lucene-core-5.3.0.jar:$OPDL/lucene-analyzers-common-5.3.0.jar:$OPDL/lucene-queryparser-5.3.0.jar:$OPDL/httpclient-4.5.jar:$OPDL/httpcore-4.4.1.jar:$OPDL/httpmime-4.5.jar prodocswing.forms.MainWin conf/Prodoc.properties

