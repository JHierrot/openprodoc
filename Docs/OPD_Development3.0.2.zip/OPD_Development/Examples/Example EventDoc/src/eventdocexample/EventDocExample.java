/*
 * Example that export to a folder the documents of a specific mimetype/extension started by an event
 */
package eventdocexample;

import prodoc.CustomTask;
import prodoc.DriverGeneric;
import prodoc.PDDocs;
import prodoc.PDException;
import prodoc.PDLog;
import prodoc.Record;

/**
 *
 * @author jhier
 */
public class EventDocExample extends CustomTask
{

//------------------------------------------------------------------------
/**
 * Example of checking if a document meets the requirements. In ths example, the document must be a PDf
 * @param Param1 Parameter 1 of the configured Event (in this example, the extension that must have the doc)
 * @param Param2 Parameter 2 of the configured Event (In this example, path to exporto to the document)
 * @param Param3 Parameter 3 of the configured Event
 * @param Param4 Parameter 4 of the configured Event
 * @param Rec  Metadata of the document that triggers the event
 * @param Drv OPD Session for retrieving additional information
 * @return true if the document meets the expected 
 */
@Override
protected boolean CustomMeetsReqRec(String Param1, String Param2, String Param3, String Param4, Record Rec, DriverGeneric Drv)
{
if (PDLog.isDebug())    
    PDLog.Debug("EventDocExample.CustomMeetsReqRec.Param1=["+Param1+"] Param2=["+Param2+"] Param3=["+Param3+"] Param4=["+Param4+"] Rec=["+Rec+"]");    
if (((String)Rec.getAttr(PDDocs.fMIMETYPE).getValue()).equalsIgnoreCase(Param1))    
    return(true);
else
    return(false);
}
//-----------------------------------------------------------------    
/**
 * 
 * @param Param1 Parameter 1 of the configured Event (in this example, the extension that must have the doc)
 * @param Param2 Parameter 2 of the configured Event (In this example, path to exporto to the document)
 * @param Param3 Parameter 3 of the configured Event
 * @param Param4 Parameter 4 of the configured Event
 * @param Doc    PDDocs Document that triggers the Event
 * @throws PDException In any Error
 */
@Override
protected void ExecuteEventDoc (String Param1,String Param2,String Param3,String Param4, PDDocs Doc)  throws PDException
{
if (PDLog.isInfo())    
    PDLog.Info("EventDocExample.ExecuteEventDoc.Param1=["+Param1+"] Param2=["+Param2+"] Param3=["+Param3+"] Param4=["+Param4+"] Doc=["+Doc.getRecSum()+"]");    
Doc.ExportXML(Param2, false);
}
//------------------------------------------------------------------------
}
