/*
 * Example of OpenProdoc Driver for storage of documents in a Folder 
 * (similar to the internal one in OpenProdoc for folders)
 */
package driverexample;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import prodoc.PDException;
import prodoc.PDExceptionFunc;
import prodoc.PDLog;
import prodoc.Record;
import prodoc.StoreCustom;

/**
 * Example of developed driver.
 * It MUST extend StoreCustom repository
 * @author Joaquín Hierro
 */
public class DriverExample extends StoreCustom
{
static final String SEP="v";

public DriverExample(String pServer, String pUser, String pPassword, String pParam, boolean pEncrypt) throws PDExceptionFunc
{
super(pServer, pUser, pPassword, pParam, pEncrypt); 
if (PDLog.isDebug())  //recommended way of trace 
    PDLog.Debug("Created Driver:"+DriverExample.class+"/"+pServer);
// if required and configured, a properties file is available through the parent method:
// Properties getProp()
// example String MyProp=getProp().getProperty("MyProp1")
}
//--------------------------------------------------------------------------
/**
 * The create method could be called from the user interface (Repositories Management) so each repository creates in its own way
 * @throws PDException in any error
 */
@Override
protected void Create() throws PDException
{
File BasePath=new File(getServer()); // each storage driver can use the Server in a way (url, path, UNC, code,..)
if (BasePath.isDirectory())
    return;
try {
BasePath.mkdirs();
} catch (Exception e)
    {// this method logs the exception AND throws again
    PDException.GenPDException("Error_creating_folder_for_StoreFS",getServer()+"="+e.getLocalizedMessage());
    }
}
//--------------------------------------------------------------------------
/**
 * The Delete method is not actually called by the risk of deleting thousands of documents
 * @throws PDException in any error
 */
@Override
protected void Destroy() throws PDException
{
File BasePath=new File(getServer());
if (!BasePath.isDirectory())
    return;
BasePath.delete();}
//--------------------------------------------------------------------------
/**
 * It is called allways BEFORE using the repository. 
 * Could be dummy, connect, create sockets, authenticate, etc. 
 * @throws PDException In any Error
 */
@Override
protected void Connect() throws PDException
{
if (PDLog.isDebug())  //recommended way of trace 
    PDLog.Debug("Connected Driver:"+DriverExample.class+"/"+getServer()+"-"+getUser());    
}
//--------------------------------------------------------------------------
/**
 * It is called allways AFTER using the repository. 
 * Could be dummy, connect, create sockets, authenticate, etc. 
 * @throws PDException In any Error
 */
@Override
protected void Disconnect() throws PDException
{
if (PDLog.isDebug())  //recommended way of trace 
    PDLog.Debug("DisConnected Driver:"+DriverExample.class+"/"+getServer()+"-"+getUser());        
}
//--------------------------------------------------------------------------
/** 
 * Do the actual insertion of the document binary. 
 * Always MUST close the input stream to avoid problems
 * and degradation.
 * @param Id OpenProdoc identifier (PDId) of the document to store
 * @param Ver Versión Label of the Document
 * @param Bytes Input stream to store
 * @param Rec   Record with Metadata of the document (just in case it used)
 * @param OPDPath Path in OpenProdoc of the document (just in case it used)
 * @return the size of the file
 * @throws PDException In any error
 */
@Override
protected int Insert(String Id, String Ver, InputStream Bytes, Record Rec, String OPDPath) throws PDException
{
VerifyId(Id);
FileOutputStream fo=null;
int Tot=0;
try {
File Path=new File(getServer());
if (!Path.isDirectory())
    Path.mkdirs();
fo = new FileOutputStream(getServer()+Id+SEP+Ver);
int readed=Bytes.read(Buffer);
while (readed!=-1)
    {
    if (isEncript())
       EncriptPass(Buffer, readed);  // another stronger algorithm for encription can be used
    fo.write(Buffer, 0, readed);
    Tot+=readed;
    readed=Bytes.read(Buffer);
    }
Bytes.close();
fo.close();
if (PDLog.isDebug())  //recommended way of trace 
    PDLog.Debug("Inserted Driver:"+DriverExample.class+"/"+getServer()+"-"+Id+SEP+Ver);        
} catch (Exception e)
    {
    PDException.GenPDException("Error_writing_to_file",Id+"/"+Ver+"="+e.getLocalizedMessage());
    }
finally
    {
    try {
    if (fo!=null)
        fo.close();
    Bytes.close();
    } catch (Exception e)
        {
        }
    }
return(Tot);
}
//--------------------------------------------------------------------------
/**
 * Deletes the binary
 * @param Id Identifier of document
 * @param Ver Identifier of version
 * @param Rec Record with Metadata of the document (not used in Filesystem storage)
 * @throws PDException In Any Error
 */
@Override
protected void Delete(String Id, String Ver, Record Rec) throws PDException
{
VerifyId(Id);
File f=new File(getServer()+Id+SEP+Ver);
f.delete();
if (PDLog.isDebug())  //recommended way of trace 
    PDLog.Debug("Deleted Driver:"+DriverExample.class+"/"+getServer()+"-"+Id+SEP+Ver);        
}
//--------------------------------------------------------------------------
/**
 * Returns the binary as InputStream
 * @param Id Identifier of document
 * @param Ver Identifier of version
 * @return an InputStream with the content
 * @throws PDException in any error
 */
@Override
protected InputStream Retrieve(String Id, String Ver, Record Rec) throws PDException
{
VerifyId(Id);    
FileInputStream in=null;
try {
in = new FileInputStream(getServer()+ Id+SEP+Ver);
} catch (FileNotFoundException ex)
    {
    PDException.GenPDException("Error_retrieving_file",Id+"/"+Ver+"="+ex.getLocalizedMessage());
    }
return(in);
}
//--------------------------------------------------------------------------
/**
 * Changes the name of e binary. Used for CheckInCheckOut,..
 * @param Id1 Identifier of original document
 * @param Ver1 Identifier of original version
 * @param Id2 Identifier of Target document
 * @param Ver2 Identifier of Target version
 * @throws PDException
 */
@Override
protected void Rename(String Id1, String Ver1, String Id2, String Ver2) throws PDException
{
VerifyId(Id1);
File f=new File(getServer()+Id1+SEP+Ver1);
File f2=new File(getServer()+Id2+SEP+Ver2);
f.renameTo(f2);
}
//--------------------------------------------------------------------------    
}
