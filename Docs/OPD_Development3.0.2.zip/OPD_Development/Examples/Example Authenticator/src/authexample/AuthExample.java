/*
 * Example of authentication system
 * JUST AN EXAMPLE, NOT AN USEFUL NOR SECURE SOLUTION
 * Use a more secure implementation
 */
package authexample;

import prodoc.PDException;
import prodoc.PDExceptionFunc;
import prodoc.PDLog;
import prodoc.security.AuthGeneric;

/**
 * Example of Authentication system that check the user/password 
 * against a list of user/passwords defined in a properties files
 * JUST AN EXAMPLE, NOT AN USEFUL NOR SECURE SOLUTION
 * @author jhier
 */
public class AuthExample extends AuthGeneric
{
/**
 * Constructor
 * @param pServer Server to authenticate
 * @param pUser User of connection to server (if need, NOT the user to authenticate)
 * @param pPassword Password of connection to server (if need, NOT the user to authenticate)
 * @param pParam Aditional param
 */
public AuthExample(String pServer, String pUser, String pPassword, String pParam)
{
super(pServer, pUser, pPassword, pParam);
if (PDLog.isDebug())  //recommended way of trace 
    PDLog.Debug("Created Auth:"+AuthExample.class+"/"+pServer);
// if required and configured, a properties file is available through the parent method:
// Properties getProp()
// example String MyProp=getProp().getProperty("MyProp1")
}
//----------------------------------------------------------------------

/**
 * Authenticates the user against the server defined and thows an exception 
 * if the authetication fails.
 * @param pUser user to authenticate
 * @param pPass Password (in clear)of the user 
 * @throws PDException if the user is nos authenticated
 */
@Override
public void Authenticate(String pUser, String pPass) throws PDException
{
String StoredPass=getProp().getProperty(pUser);
if (StoredPass!=null && StoredPass.equals(pPass))
    return;
// this method logs the exception AND throws again
PDExceptionFunc.GenPDException("Error authenticating:"+AuthExample.class+"/"+getServer(), "User="+pUser);
}
//----------------------------------------------------------------------    
}
