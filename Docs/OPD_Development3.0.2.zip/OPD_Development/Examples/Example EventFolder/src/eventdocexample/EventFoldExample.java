/*
 * Example that export to a folder all the documents to a Folder started by an event
 */

package eventdocexample;

import prodoc.CustomTask;
import prodoc.DriverGeneric;
import prodoc.PDException;
import prodoc.PDFolders;
import prodoc.PDLog;
import prodoc.Record;

/**
 *
 * @author jhier
 */
public class EventFoldExample extends CustomTask
{
//------------------------------------------------------------------------
/** Method that check if the object meets  the process
 * Check if the folder is under another folder
 * @param Param1 Parameter 1 of the configured Event
 * @param Param2 Parameter 2 of the configured Event
 * @param Param3 Parameter 3 of the configured Event
 * @param Param4 Parameter 4 of the configured Event
 * @param Rec with the data
 * @param Drv generic driver
 * @return true if the record attributes of Folder meets the conditions
 * @throws prodoc.PDException in any error
 */
@Override
protected boolean CustomMeetsReqRec(String Param1, String Param2, String Param3, String Param4, Record Rec, DriverGeneric Drv)  throws PDException
{       
PDFolders Fold=new PDFolders(Drv);  
String IdUnder=Fold.getIdPath(Param1);
Fold.setPDId((String)Rec.getAttr(PDFolders.fPDID).getValue());
if (Fold.IsUnder(IdUnder)) 
    return(true);
else
    return(false);
}
//-----------------------------------------------------------------    
/** Method that do the process
 * Example that exports the metadata of all the contained documents to path Param1
 * @param Param1 Parameter 1 of the configured Event
 * @param Param2 Parameter 2 of the configured Event
 * @param Param3 Parameter 3 of the configured Event
 * @param Param4 Parameter 4 of the configured Event
 * @param Fold   PDFolders Folder object that triggers the Event
 * @throws PDException In any Error
 */
@Override
protected void ExecuteEventFold(String Param1, String Param2,String Param3, String Param4, PDFolders Fold) throws PDException
{
if (PDLog.isInfo())    
    PDLog.Info("EventFoldExample.ExecuteEventFold.Param1=["+Param1+"] Param2=["+Param2+"] Param3=["+Param3+"] Param4=["+Param4+"] Doc=["+Fold.getRecSum()+"]");        
Fold.ExportDocs(Param2);
}
//------------------------------------------------------------------------
}
