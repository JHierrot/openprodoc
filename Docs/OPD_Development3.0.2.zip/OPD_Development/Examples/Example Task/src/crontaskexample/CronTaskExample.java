/*
 * Example of Task started schedulled  for exporting to XML the document metadata
 */
package crontaskexample;

import prodoc.Cursor;
import prodoc.CustomTask;
import prodoc.DriverGeneric;
import prodoc.PDDocs;
import prodoc.PDException;
import prodoc.PDLog;
import prodoc.Record;

/**
 *
 * @author jhier
 */
public class CronTaskExample extends CustomTask
{
//-----------------------------------------------------------------        
@Override
protected Cursor CursorCustom(DriverGeneric Drv, String ObjectType, String Filter, String param, String param2, String param3, String param4)  throws PDException
{
if (PDLog.isInfo())    
    PDLog.Info("CronTaskExample.CursorCustom");
try {
PDDocs D=new PDDocs(Drv, ObjectType);
return(D.SearchSelect(param));
} catch (Exception Ex)
    {
    // catch any exception and trace/convert in PDException
    PDException.GenPDException("CronTaskExample.Error Creating Cursor:",Ex.getLocalizedMessage());
    return (null);
    }
finally 
    {
    // close any resources opened
    }
}
//-----------------------------------------------------------------    
@Override
protected void CustomCronTask(DriverGeneric Drv, String objType, String objFilter, String param, String param2, String param3, String param4)  throws PDException
{
Cursor CursorCustom = null;
try {
CursorCustom = CursorCustom( Drv, objType, objFilter, param, param2, param3, param4);
Record NextRec = Drv.NextRec(CursorCustom);
while (NextRec!=null)
    {
    PDDocs D=new PDDocs(Drv);
    D.assignValues(NextRec);
    D.ExportXML(param2, true);
    NextRec = Drv.NextRec(CursorCustom);
    }
} catch (Exception Ex)
    {
    PDLog.Error(Ex.getLocalizedMessage());
    }
finally
    {
     if (CursorCustom != null)
        {
        try { 
        Drv.CloseCursor(CursorCustom);
        } catch (Exception e)
            {
            PDLog.Error(e.getLocalizedMessage());
            }
        }
    }
}
//-----------------------------------------------------------------        
}
