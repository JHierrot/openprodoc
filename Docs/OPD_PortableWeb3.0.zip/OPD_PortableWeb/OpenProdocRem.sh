export OPDL=./webapps/ProdocWeb2/WEB-INF/lib
java -Dfile.encoding=UTF-8 -classpath .:$OPDL/Prodoc.jar:ProdocSwing.jar:$OPDL/hsqldb.jar:$OPDL/lucene-core-7.3.1.jar:$OPDL/lucene-analyzers-common-7.3.1.jar:$OPDL/lucene-queryparser-7.3.1.jar:$OPDL/tika-app-1.18.jar:$OPDL/commons-net-3.6.jar: prodocswing.forms.MainWin conf/ProdocRem.properties
