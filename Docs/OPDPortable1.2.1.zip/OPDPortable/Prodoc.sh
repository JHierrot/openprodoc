java -Dfile.encoding=UTF-8 -classpath .:./lib:./lib/Prodoc.jar:ProdocSwing.jar:./lib/log4j-1.2.16.jar:./lib/hsqldb.jar  prodocswing.forms.MainWin $1
