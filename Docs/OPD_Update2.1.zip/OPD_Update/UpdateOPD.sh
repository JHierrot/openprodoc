java -Dfile.encoding=UTF-8 -classpath .:./lib:./lib/Prodoc.jar:OPDUpdate.jar:./lib/log4j-1.2.16.jar:./lib/hsqldb.jar  opdupdate.UpdateOPD
