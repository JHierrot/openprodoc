java -Dfile.encoding=UTF-8 -classpath .:./lib:ProdocInstall.jar  prodocinstall.ConfigConection $1 $2
